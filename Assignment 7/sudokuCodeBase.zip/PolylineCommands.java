

public interface PolylineCommands 
{

	public void moveTo( float x, float y );
	
	public void lineTo( float x, float y );
}
