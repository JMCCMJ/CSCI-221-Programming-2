
public class FileFormatException extends Exception
{
	public FileFormatException()
	{
		super();
	}
	
	public FileFormatException( String description )
	{
		super( description );
	}
}
